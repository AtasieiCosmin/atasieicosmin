package siit.services;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;
import siit.dao.CustomerDao;
import siit.dao.OrderDao;
import siit.dao.ProductDao;
import siit.exceptions.ValidationException;
import siit.model.Customer;
import siit.model.Order;

@Service
public class CustomersService {

    @Autowired
    private CustomerDao customerDao;

    @Autowired
    private OrderDao orderDao;

    @Autowired
    private ProductDao productDao;

    public List<Customer> getCustomers() {
        return customerDao.findAll();
    }

    public List<Customer> getCustomersByName(String name) {
        return customerDao.findByName(name);
    }

    public Customer getCustomerById(int id) {
        return customerDao.findById(id);
    }

    public Customer getCustomerByIdWithOrders(int id) {
        Customer customer = customerDao.findById(id);
        customer.setOrders(orderDao.getByCustomerId(id));
        return customer;
    }

    public void updateCustomer(Customer customer) {
        if ( ! customer.getPhoneNumber().matches("\\d+")) {
            throw new ValidationException("phoneNumber.malformed");
        }
        customerDao.update(customer);
    }

    @Transactional
    public void deleteOrder(long orderId) {
        orderDao.delete(orderId);
    }

    public void addOrderForCustomer(int customerId, Order order) {
        order.setPlaced(Instant.now());
        orderDao.addOrderForCustomer(customerId, order);
    }

}
