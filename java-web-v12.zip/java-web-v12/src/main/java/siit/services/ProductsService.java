package siit.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import siit.dao.ProductDao;
import siit.model.Product;

import java.util.List;

@Service
public class ProductsService {

    @Autowired
    private ProductDao productDao;

    public List<Product> getProducts(){
        return productDao.findAll();
    }

}
