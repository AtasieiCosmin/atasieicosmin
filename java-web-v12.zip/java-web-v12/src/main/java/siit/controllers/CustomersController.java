package siit.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import siit.exceptions.ValidationException;
import siit.model.Customer;
import siit.services.CustomersService;

import java.util.Locale;

@Controller
public class CustomersController {

    @Autowired
    private CustomersService customersService;

    @Autowired
    private ApplicationContext appContext;

    @GetMapping("/customers")
    public ModelAndView getCustomers(@RequestParam(required = false) String nameContains) {
        ModelAndView mav = new ModelAndView("customer-list");

        if (nameContains == null) {
            mav.addObject("customers", customersService.getCustomers());
        } else {
            mav.addObject("customers", customersService.getCustomersByName(nameContains));
        }
        return mav;
    }

    @GetMapping("/customers/{id}/edit")
    public ModelAndView displayEdit(@PathVariable int id) {
        ModelAndView mav = new ModelAndView("customer-edit");
        mav.addObject("customer", customersService.getCustomerById(id));
        return mav;
    }

    @PostMapping("/customers/{id}/edit")
    public ModelAndView doEdit(@ModelAttribute Customer customer) {
        try {
            customersService.updateCustomer(customer);
        } catch (ValidationException e) {
            ModelAndView mav = new ModelAndView("customer-edit");
            mav.addObject("error", appContext.getMessage(
                    e.getCode(), new Object[]{}, Locale.forLanguageTag("ro")));
            return mav;
        }
        return new ModelAndView("redirect:/customers");
    }

}
