package siit.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import siit.model.Customer;
import siit.model.Order;
import siit.services.CustomersService;

@Controller
public class CustomerOrdersController {

    @Autowired
    private CustomersService customersService;

    @GetMapping("/customers/{id}/orders")
    public ModelAndView displayOrders(@PathVariable int id) {
        ModelAndView mav = new ModelAndView("customer-orders");
        mav.addObject("customer", customersService.getCustomerByIdWithOrders(id));
        return mav;
    }

    @GetMapping("/customers/{customerId}/orders/{orderId}/delete")
    public ModelAndView deleteOrder(@PathVariable long customerId, @PathVariable long orderId) {
        customersService.deleteOrder(orderId);
        return new ModelAndView("redirect:/customers/" + customerId + "/orders");
    }

    @GetMapping("/customers/{customerId}/orders/add")
    public ModelAndView displayEdit(@PathVariable int customerId) {
        ModelAndView mav = new ModelAndView("customer-order-add");
        mav.addObject("customer", customersService.getCustomerById(customerId));
        return mav;
    }

    @PostMapping("/customers/{customerId}/orders/add")
    public ModelAndView doEdit(@PathVariable int customerId, @ModelAttribute Order order) {
        customersService.addOrderForCustomer(customerId, order);
        return new ModelAndView("redirect:/customers/" + customerId + "/orders");
    }

}
