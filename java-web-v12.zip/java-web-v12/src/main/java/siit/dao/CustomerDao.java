package siit.dao;

import java.util.List;

import siit.model.Customer;
import siit.model.Order;

public interface CustomerDao {

    List<Customer> findAll();

    Customer findById(long id);

    List<Customer> findByName(String name);

    void update(Customer customer);

}
