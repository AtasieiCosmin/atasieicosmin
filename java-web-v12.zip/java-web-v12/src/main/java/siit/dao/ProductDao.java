package siit.dao;

import siit.model.Product;

import java.util.List;

public interface ProductDao {

    List<Product> findAll();

    Product findById(long id);
}
