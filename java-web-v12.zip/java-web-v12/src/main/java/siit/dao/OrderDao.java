package siit.dao;

import siit.model.Order;

import java.util.List;

public interface OrderDao {

    List<Order> findAll();

    Order findById(long id);

    void update(Order Order);

    List<Order> getByCustomerId(int id);

    void delete(long orderId);

    void addOrderForCustomer(int customerId, Order order);

}
