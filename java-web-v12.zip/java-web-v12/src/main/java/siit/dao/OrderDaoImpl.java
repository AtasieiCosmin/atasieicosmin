package siit.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import siit.model.Order;

import java.sql.*;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

@Repository
public class OrderDaoImpl implements OrderDao {

    public static final Calendar UTC_CALENDAR =
            Calendar.getInstance(TimeZone.getTimeZone("UTC"));

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    @Override
    public List<Order> findAll() {
        return jdbcTemplate.query("select * from Orders", this::mapRowToOrder);
    }

    @Override
    public Order findById(long id) {
        return jdbcTemplate.queryForObject("select * from Orders where id = ?",
                this::mapRowToOrder, id);
    }

    @Override
    public List<Order> getByCustomerId(int id) {
        return jdbcTemplate.query("select * from Orders where customer_id = ?",
                this::mapRowToOrder, id);
    }

    @Override
    public void delete(long orderId) {
        jdbcTemplate.update("delete from orders_products where order_id = ?", orderId);
        jdbcTemplate.update("delete from orders where id = ?", orderId);
    }

    @Override
    public void addOrderForCustomer(int customerId, Order order) {
        jdbcTemplate.update(
                "insert into orders (customer_id, number, placed) values (?,?,?)",
                ps -> mapOrderToRow(ps, customerId, order));
    }

    private void mapOrderToRow(PreparedStatement ps, int customerId, Order order) throws SQLException {
        ps.setLong(1, customerId);
        ps.setString(2, order.getNumber());
        ps.setTimestamp(3, Timestamp.from(order.getPlaced()), UTC_CALENDAR);
    }

    @Override
    public void update(Order order) {
//        Object[] params = {order.getName(), order.getPhoneNumber(),order.getId()};
//        int[] types = { Types.VARCHAR, Types.VARCHAR, Types.BIGINT};
//        jdbcTemplate.update("update Orders set name = (?), phone=(?) WHERE ID = (?)", params, types);
        /* TODO Refactor so it will work with PreparedStatements.
         *  jdbcTemplate.update(...)*/

    }

    private Order mapRowToOrder(ResultSet rs, int rowNum) throws SQLException {
        Order order = new Order();
        order.setId(rs.getLong("id"));
        order.setNumber(rs.getString("number"));
        order.setPlaced(rs.getTimestamp("placed", UTC_CALENDAR).toInstant());
        return order;
    }
}
