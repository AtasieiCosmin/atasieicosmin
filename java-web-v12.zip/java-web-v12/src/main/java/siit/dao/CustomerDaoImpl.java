package siit.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import siit.model.Customer;
import siit.model.Order;

@Repository
public class CustomerDaoImpl implements CustomerDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Customer> findAll() {
        return jdbcTemplate.query("select * from customers", this::mapRowToCustomer);
    }

    @Override
    public Customer findById(long id) {
        return jdbcTemplate.queryForObject("select * from customers where id = ?",
                this::mapRowToCustomer, id);
    }

    @Override
    public List<Customer> findByName(String name) {
        return jdbcTemplate.query("select * from customers where upper(name) like upper(?)",
                this::mapRowToCustomer, "%" + name + "%");
    }

    @Override
    public void update(Customer customer) {
        Object[] params = {customer.getName(), customer.getPhoneNumber(),customer.getId()};
        int[] types = { Types.VARCHAR, Types.VARCHAR, Types.BIGINT};
        jdbcTemplate.update("update customers set name = (?), phone=(?) WHERE ID = (?)", params, types);
        /* TODO Refactor so it will work with PreparedStatements.
        *  jdbcTemplate.update(...)*/

    }

    private Customer mapRowToCustomer(ResultSet rs, int rowNum) throws SQLException {
        Customer customer = new Customer();
        customer.setId(rs.getLong("id"));
        customer.setName(rs.getString("name"));
        customer.seteMail(rs.getString("email"));
        customer.setPhoneNumber(rs.getString("phone"));
        return customer;
    }
}
